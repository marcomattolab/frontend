export interface Task {
  id: number,
  name: string,
  priority: number
}
