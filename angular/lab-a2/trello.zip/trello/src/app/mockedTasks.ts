import { Task } from "./task";

export const TASKSMK: Task[] = [
  {id:12, name:'Task1', priority:1 },
  {id:13, name:'Task2', priority:1 },
  {id:14, name:'Task3', priority:3 },
  {id:15, name:'Task4', priority:1 },
  {id:16, name:'Task5', priority:4 }
];


