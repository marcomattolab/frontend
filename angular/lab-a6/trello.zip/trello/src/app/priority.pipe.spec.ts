import { PriorityPipe } from './priority.pipe';

describe('PriorityPipe', () => {
  it('create an instance', () => {
    const pipe = new PriorityPipe();
    expect(pipe).toBeTruthy();
  });
});
