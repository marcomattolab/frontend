import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { TasksComponent } from './tasks/tasks.component';
import { PriorityPipe } from './priority.pipe';
import { TaskDetailComponent } from './task-detail/task-detail.component';
import { ToastComponent } from './shared/components/toast/toast.component';
import { RxjsDemoComponent } from './rxjs-demo/rxjs-demo.component';
import { AlfaComponent } from './features/rxjs/pages/alfa/alfa.component';
import { BetaComponent } from './features/rxjs/pages/beta/beta.component';
import { RegistrationComponent } from './features/reactive-forms/registration/registration.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MeteoComponent } from './features/meteo/meteo.component';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    TasksComponent,
    PriorityPipe,
    TaskDetailComponent,
    ToastComponent,
    RxjsDemoComponent,
    AlfaComponent,
    BetaComponent,
    RegistrationComponent,
    MeteoComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
