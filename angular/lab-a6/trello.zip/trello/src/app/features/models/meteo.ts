export class Meteo {
  humidity?: string;
  icon?: string;
  temperature?: string;
  error: boolean= false;
}
