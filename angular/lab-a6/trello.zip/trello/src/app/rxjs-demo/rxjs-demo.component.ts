import { Component } from '@angular/core';
import { of } from 'rxjs';

@Component({
  selector: 'app-rxjs-demo',
  templateUrl: './rxjs-demo.component.html',
  styleUrls: ['./rxjs-demo.component.css']
})
export class RxjsDemoComponent {


  constructor(){
  }


  startObservable():void{
    console.log('Start observable... ');
    of(1,2,3).subscribe(
       //x=> console.log(x)
       {
        next: value => console.log('next:', value),
        error: err => console.log('error:', err),
        complete: () => console.log('the end')
       }
    )
  }

}
