import { Component, EventEmitter, Input, OnInit, Output, OnDestroy, OnChanges, SimpleChanges} from '@angular/core';
import { Task } from '../task';

@Component({
  selector: 'app-task-detail',
  templateUrl: './task-detail.component.html',
  styleUrls: ['./task-detail.component.css']
})
export class TaskDetailComponent implements OnInit, OnDestroy, OnChanges{

  @Input() mySelectedTask?: Task;
  @Output() deleteEvent = new EventEmitter<Task>();

  constructor(){
    console.log("# constructor of TaskDetailComponent !");
  }

  ngOnChanges(changes: SimpleChanges): void {
    console.log("# ngOnChanges *** ");
  }

  ngOnDestroy(): void {
    console.log("# ngOnDestroy has been called !!! ");
  }

  ngOnInit(): void {
    console.log("# ngOnInit has been called !! ");
  }

  popolaTaskName(): void{
    if(this.mySelectedTask){
      this.mySelectedTask.name= "Marco";
    }
  }

  delete(value : Task): void {
    console.log("Metodo delete del child");
    this.deleteEvent.emit(value);
  }


}
