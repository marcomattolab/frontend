import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ListRxjsComponent } from './listRxjs.component';

describe('ListRxjsComponent', () => {
  let component: ListRxjsComponent;
  let fixture: ComponentFixture<ListRxjsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListRxjsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ListRxjsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
