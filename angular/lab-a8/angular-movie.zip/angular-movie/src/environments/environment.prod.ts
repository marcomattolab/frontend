export const environment = {
  production: true,
  theMovieDBApi: '<API-KEY>'
};
