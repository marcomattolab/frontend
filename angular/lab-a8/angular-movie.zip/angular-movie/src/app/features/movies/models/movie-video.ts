export class MovieVideo {

  public id: number;
  public results: Array<any>;
  public name: string;
  public url: any;
  public key: string;

}
