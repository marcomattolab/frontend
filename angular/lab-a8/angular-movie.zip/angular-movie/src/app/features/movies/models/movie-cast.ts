export class MovieCast {

  public cast: Array<any>;
  public crew: Array<any>;
  public id: number;
  public character: any;
  public profile_path: any;

}
