export enum Color {
  RED = '#f44336',
  BLUE = '#2196f3',
  GREEN = '#4caf50',
}
