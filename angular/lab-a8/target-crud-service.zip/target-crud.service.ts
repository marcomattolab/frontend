import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ConfigService } from '@ngx-config/core';
import { Observable } from 'rxjs';
import { ITarget } from '../../../model/target.model';

@Injectable({
  providedIn: 'root'
})
export class TargetCrudService {
  private apiURL: any;

  constructor(configService: ConfigService, private http: HttpClient) {
    this.apiURL = configService.getSettings("api_base_url");
  }

  getAll(): Observable<Array<ITarget>> {
    return this.http.get<Array<ITarget>>(`${this.apiURL}/api/targets`);
  }

  getTargetById(id: string): Observable<ITarget> {
    return this.http.get<ITarget>(`${this.apiURL}/api/targets/${id}`);
  }

  createTarget(target: ITarget): Observable<ITarget> {
    let httpHeaders = new HttpHeaders({ 'Content-type': 'application/json' });
    return this.http.post<ITarget>(`${this.apiURL}/api/targets`, target, { headers: httpHeaders });
  }

  deleteTargetById(id: string): any {
    return this.http.delete<ITarget>(`${this.apiURL}/api/targets/${id}`);
  }

  updateTarget(target: ITarget): Observable<ITarget> {
    let httpHeaders = new HttpHeaders({ 'Content-type': 'application/json' });
    return this.http.put<ITarget>(`${this.apiURL}/api/targets/${target.id}`, target, {
      headers: httpHeaders,
    });
  }

}
