

export interface ITarget {
  id?: number;
  type?: string;
  name?: string;
  note?: string | null;
  createdBy?: string | null;
}

export class Target implements ITarget {
  constructor(
    public id?: number,
    public type?: string,
    public name?: string,
    public note?: string | null,
    public createdBy?: string | null,
  ) {}
}

export function getTargetIdentifier(target: ITarget): number | undefined {
  return target.id;
}