import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormArray, FormBuilder } from '@angular/forms';
import { CategoryService } from 'src/app/category-mocked.service';
import { IBedCategory, ICategory } from 'src/app/categoryData';

/** See https://blog.angular-university.io/angular-form-array/ */
@Component({
  selector: 'app-my-categories',
  templateUrl: './my-categories.component.html',
  styleUrls: ['./my-categories.component.css']
})
export class MyCategoriesComponent implements OnInit {
  categoryForm: FormGroup;
  availableLanguages: string[] = [];
  bedCategories: IBedCategory[] = [];
  selectedTabIndex = 0;

  constructor(private categoryService: CategoryService) {
    // Initialize the form
    this.categoryForm = new FormGroup({
      bedCategories: new FormArray([])
    });
  }

  ngOnInit(): void {
    this.categoryService.getData().subscribe(data => {
      this.availableLanguages = data.availableLanguages; //['DE_CH', 'FR', 'IT', 'EN'];
      this.bedCategories = data.bedCategories;
      this.buildForm();
    });
  }

  buildForm(): void {
    // Populate form array controls based on availableLanguages and bedCategories
    this.availableLanguages.forEach(lang => {
      const bedCategory = this.bedCategories.find(bedCategory => bedCategory.language === lang) ;
      if (bedCategory!=undefined){
        const categoryBedFormGroup = this.createBedCategoryFormGroup(bedCategory);
        (this.categoryForm.get('bedCategories') as FormArray).push(categoryBedFormGroup);
      }else{
        const categoryBedFormGroup = this.createEmptyBedCategoryFormGroup(lang);
        (this.categoryForm.get('bedCategories') as FormArray).push(categoryBedFormGroup);
      }
    });
    //console.log(this.categoryForm.value);
  }

  createEmptyBedCategoryFormGroup(lang: string): FormGroup {
    return new FormGroup({
      language: new FormControl(lang),
      servicedCategories: new FormArray([]),
      unservicedCategories: new FormArray([]),
    });
  }

  createBedCategoryFormGroup(bedCategory: IBedCategory): FormGroup {
    let servicedCategories = this.createCategoryFormArray(bedCategory?.servicedCategories);
    let unservicedCategories = this.createCategoryFormArray(bedCategory?.unservicedCategories);
    return new FormGroup({
      language: new FormControl(bedCategory?.language),
      servicedCategories: servicedCategories,
      unservicedCategories: unservicedCategories,
    });
  }

  get bedCategoriesArray(): FormArray{
    return this.categoryForm.get('bedCategories') as FormArray;
  }

  getServicedCategories(groupIndex: number): FormArray {
    return this.bedCategoriesArray
    .at(groupIndex)
    .get('servicedCategories') as FormArray;
  }

  getUnservicedCategories(groupIndex: number): FormArray {
    return this.bedCategoriesArray
    .at(groupIndex)
    .get('unservicedCategories') as FormArray;
  }

  createCategoryFormArray(categories: ICategory[]): FormArray {
    return new FormArray(categories.map(category => this.createCategoryFormGroup(category)));
  }

  createCategoryFormGroup(category: ICategory): FormGroup {
    return new FormGroup({
      index: new FormControl(category.index),
      label: new FormControl(category.label),
      labelShort: new FormControl(category.labelShort),
      labelId: new FormControl(category.labelId),
      categoryId: new FormControl(category.categoryId)
    });
  }

  createEmptyCategoryFormGroup(): FormGroup {
    return new FormGroup({
      index: new FormControl(),
      label: new FormControl(),
      labelShort: new FormControl(),
      labelId: new FormControl(),
      categoryId: new FormControl()
    });
  }

  addServicedCategory(bedCategoryIndex: number): void {
    const servicedCategoriesArray = this.bedCategoriesArray.at(bedCategoryIndex).get('servicedCategories') as FormArray;
    let emptyCategory = this.createEmptyCategoryFormGroup();
    servicedCategoriesArray.push( emptyCategory );
  }

  removeServicedCategory(bedCategoryIndex: number, servicedCategoryIndex: number): void {
    const servicedCategoriesArray = this.bedCategoriesArray.at(bedCategoryIndex).get('servicedCategories') as FormArray;
    servicedCategoriesArray.removeAt(servicedCategoryIndex);
  }

  get servicedCategoriesArray(): FormArray{
    return this.categoryForm.get('servicedCategories') as FormArray;
  }

  addUnservicedCategory(bedCategoryIndex: number): void {
    const unservicedCategoriesArray = this.bedCategoriesArray.at(bedCategoryIndex).get('unservicedCategories') as FormArray;
    let emptyCategory = this.createEmptyCategoryFormGroup();
    unservicedCategoriesArray.push( emptyCategory );
  }

  removeUnservicedCategory(bedCategoryIndex: number, unservicedCategoryIndex: number): void {
    const unservicedCategoriesArray = this.bedCategoriesArray.at(bedCategoryIndex).get('unservicedCategories') as FormArray;
    unservicedCategoriesArray.removeAt(unservicedCategoryIndex);
  }

  get unservicedCategoriesArray(): FormArray{
    return this.categoryForm.get('unservicedCategories') as FormArray;
  }

  onSubmit(): void {
    if (this.categoryForm.valid) {
      console.log(this.categoryForm.value);
      const formData: IBedCategory[] = [
        ...this.categoryForm.value['bedCategories']
      ];
      console.log(formData);
    }
  }

}
