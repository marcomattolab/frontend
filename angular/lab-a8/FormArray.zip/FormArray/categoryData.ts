export interface ICategory {
  index: number;
  label: string;
  labelShort: string;
  labelId: number;
  categoryId: number;
}

export interface IBedCategory {
  language: string;
  servicedCategories: ICategory[];
  unservicedCategories: ICategory[];
}

export interface ICategoryData {
  availableLanguages: string[];
  bedCategories: IBedCategory[];
}
