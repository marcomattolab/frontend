import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

export interface ICategory {
  index: number;
  label: string;
  labelShort: string;
  labelId: number;
  categoryId: number;
}

export interface IBedCategory {
  language: string;
  servicedCategories: ICategory[];
  unservicedCategories: ICategory[];
}

export interface ICategoryData {
  availableLanguages: string[];
  bedCategories: IBedCategory[];
}


@Injectable({
  providedIn: 'root'
})
export class CategoryService {

constructor() { }


getData(): Observable<ICategoryData> {
  let mydata: ICategoryData = {
    "availableLanguages": [
        "DE_CH",
        "FR",
        "IT",
        "EN"
    ],
    "bedCategories": [
        {
            "language": "DE_CH",
            "servicedCategories": [
                {
                    "index": 1,
                    "label": "Massenlager",
                    "labelShort": "-",
                    "labelId": 1,
                    "categoryId": 1
                },
                {
                    "index": 2,
                    "label": "Zimmer",
                    "labelShort": "-",
                    "labelId": 2,
                    "categoryId": 2
                },
                {
                    "index": 3,
                    "label": "2er Zimmer",
                    "labelShort": "-",
                    "labelId": 54,
                    "categoryId": 13
                },
                {
                    "index": 4,
                    "label": "4er Zimmer",
                    "labelShort": "-",
                    "labelId": 60,
                    "categoryId": 14
                }
            ],
            "unservicedCategories": [
                {
                    "index": 11,
                    "label": "Winterraum",
                    "labelShort": "-",
                    "labelId": 80,
                    "categoryId": 23
                }
            ]
        },
        {
            "language": "FR",
            "servicedCategories": [
                {
                    "index": 1,
                    "label": "dortoirs",
                    "labelShort": "-",
                    "labelId": 4,
                    "categoryId": 1
                },
                {
                    "index": 2,
                    "label": "chambres",
                    "labelShort": "-",
                    "labelId": 5,
                    "categoryId": 2
                },
                {
                    "index": 3,
                    "label": "quii se bon",
                    "labelShort": "-",
                    "labelId": 56,
                    "categoryId": 13
                },
                {
                    "index": 4,
                    "label": "ola francuise",
                    "labelShort": "-",
                    "labelId": 58,
                    "categoryId": 14
                }
            ],
            "unservicedCategories": [
                {
                    "index": 11,
                    "label": "Winterraum FR",
                    "labelShort": "-",
                    "labelId": 79,
                    "categoryId": 23
                }
            ]
        }
    ]
  };

  return of(mydata);
}


}
