import { Component, OnDestroy} from '@angular/core';
import { MessageService } from '../../service/message.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-beta',
  templateUrl: './beta.component.html',
  styleUrls: ['./beta.component.css']
})
export class BetaComponent implements OnDestroy {
  message: any;
  subscribe?: Subscription;

  constructor(private messageService: MessageService){
  }

  ngOnDestroy(): void {
     this.subscribe?.unsubscribe();
  }


  leggiSottoscrizione():void{
    console.log("# leggiSottoscrizione");
    this.subscribe = this.messageService.onMessage().subscribe( m => this.message = m);
  }

}
