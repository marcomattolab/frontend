import { Component } from '@angular/core';
import { MessageService } from '../../service/message.service';

@Component({
  selector: 'app-alfa',
  templateUrl: './alfa.component.html',
  styleUrls: ['./alfa.component.css']
})
export class AlfaComponent {

  constructor(private messageService: MessageService){
  }

  sendMessage(){
    console.log("Message from Alfa");
    this.messageService.sendMessage("Message from Alfa "+ Math.random());
  }

  clearMessage(){
    this.messageService.clear();
  }
}
