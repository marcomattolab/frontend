import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from 'src/app/customer';

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomersComponent {
  customers?: Customer[]; //Get customers

  constructor(private r:Router){
  }

  goMeteo():void{
    this.r.navigateByUrl('meteo');
    //this.r.navigate(['meteo']);
  }
}
