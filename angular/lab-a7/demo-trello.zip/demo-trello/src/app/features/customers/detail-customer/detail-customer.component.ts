import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-detail-customer',
  templateUrl: './detail-customer.component.html',
  styleUrls: ['./detail-customer.component.css']
})
export class DetailCustomerComponent implements OnInit{
  id?: string;

  constructor(private ar: ActivatedRoute /*, private myService: MessageService*/){
  }

  ngOnInit(): void {
    //this.id = this.ar.snapshot.params['id'];
    //console.log("## Id = " + this.id);

    //(RxJS) Retrieve as Observable
    this.ar.params.subscribe( p => this.id = p['id']  );
    //this.ar.params.subscribe( params => this.id = parseInt(params['id'])  );


    //Customers[] myScistomers= myService.getByID(this.id);
  }



}
