import { Component } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-meteo',
  templateUrl: './meteo.component.html',
  styleUrls: ['./meteo.component.css']
})
export class MeteoComponent {

  constructor(private translate: TranslateService) {
  }

  useLanguage(language: string): void{
    this.translate.use(language);
  }

  traduciEtichetta():void{
    let message = this.translate.instant('demo.text'); //Traduce lato TS
    this.showModal(message);
  }

  /** Componente Shared */
  showModal(msg: string): void{
    console.log("## "+msg);
  }
}
