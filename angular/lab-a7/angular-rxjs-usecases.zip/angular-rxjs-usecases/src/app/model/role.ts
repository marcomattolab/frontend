
export interface Role {
  id: number;
  roleName: string;
}
