export const ADMIN = 'admin';
export const MODERATOR = 'moderator';
export const USER = 'user';
export type UserRoles = typeof ADMIN | typeof MODERATOR | typeof USER;

export interface Auth {
  token: string;
  displayName: string;
  role: UserRoles;
}

