import { Injectable } from '@angular/core';
import { HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, delay, first, mergeMap, withLatestFrom } from 'rxjs/operators';
import { iif } from 'rxjs';
import { AuthService } from './auth.service';

/**
 * The AuthInterceptor class uses RxJS operators to manipulate the requests and responses in order to handle authentication and error handling.
 *
 * Here is an explanation of some of the RxJS operators used in the code:
 * first(): Emits only the first value emitted by the source observable. In this case, it ensures that the interceptor only uses the initial value
 * of the isLogged$ observable and ignores any subsequent values.    See: https://www.learnrxjs.io/learn-rxjs/operators/filtering/first
 *
 * withLatestFrom(this.authService.token$): Combines the latest value from the source observable (isLogged$) with the latest value from the token$ observable,
 * emitting an array of the form [isLogged, token].   See: https://www.learnrxjs.io/learn-rxjs/operators/combination/withlatestfrom
 *
 * mergeMap(([isLogged, tk]) => {...}): Maps each value from the source observable to a new observable,
 * then flattens all of the resulting observables into a single observable.
 * In this case, it's used to decide whether to add the Authorization header to the request or not.
 *
 * iif(() => isLogged && req.url.includes('localhost'), trueCase, falseCase): Emits the trueCase or falseCase observables
 * based on the result of the provided condition function.
 * In this case, it's used to determine whether the user is logged in and the request is going to a localhost URL,
 * in which case the Authorization header will be added to the request.
 *
 * delay(1000): Delays the emissions of the source observable by the specified duration.
 * In this case, it's used to simulate a delay of 1 second.
 *
 * catchError(err => {...}): Catches errors emitted by the source observable and maps them to a new observable.
 * In this case, it's used to handle HTTP errors, such as 401 or 404, and perform specific actions based on the error status.
 *
 */
@Injectable({ providedIn: 'root' })
export class AuthInteceptor implements HttpInterceptor {

  constructor(private authService: AuthService) {}

  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {

    return this.authService.isLogged$
      .pipe(
        first(),
        withLatestFrom(this.authService.token$),
        mergeMap(([isLogged, tk]) => {
          return iif(
            () => isLogged && req.url.includes('localhost'),
            next.handle(req.clone({ setHeaders: { Authorization: `Bearer ${tk}` } })),
            next.handle(req)
          );
        }),
        // simulate throttling
        delay(1000),
        // error handler
        catchError(err => {
          if (err instanceof HttpErrorResponse) {
            switch (err.status) {
              case 401:
                // token expired
                break;
              default:
              case 404:
                this.authService.logout();
                break;
            }
          }
          return of(err); // or throwError
        })
      );
  }
}
