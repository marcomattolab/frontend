# RxJS usecases for Angular

This repository contains source code about "RxJS: usecases".

---

## Installation

1. Clone this repository

```
git clone <repo>
```

2. Install dependencies

```
cd project_name
npm install
```

3. Run project
```
npm start
```

4. Run JSON Server (Fake REST API server)

```
npm run server
```
