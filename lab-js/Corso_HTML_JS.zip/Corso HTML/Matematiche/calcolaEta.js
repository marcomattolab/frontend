
function calcolaEta(annoCorrente, annoNascita) {
  var eta = annoCorrente - annoNascita;
  var anniPerRaggiungere100 = 100 - eta;

  return [eta, anniPerRaggiungere100];
}

// Esempio di utilizzo
var annoCorrente = 2023;
var annoNascita = 1990;

var risultati = calcolaEta(annoCorrente, annoNascita);
var eta = risultati[0];
var anniPerRaggiungere100 = risultati[1];

console.log("Età: " + eta);
console.log("Anni necessari per raggiungere i 100: " + anniPerRaggiungere100);
