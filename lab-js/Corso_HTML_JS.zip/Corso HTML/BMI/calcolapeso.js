const peso=document.getElementById('peso'); 
const altezza=document.getElementById('altezza');
let bmi;


function calcolaBMI(){
    console.log('peso=>'+ peso.value);
    console.log('altezza=>'+ altezza.value);
    bmi=peso.value/(altezza.value*altezza.value);
    console.log('bmi=>'+ bmi);
    if(bmi<19){
        document.getElementById('immagine').src='Sottopeso.jpg';    
        document.getElementById('paragrafo').innerHTML="sei sottopeso e il tuo BMI e': " +Math.round(bmi);
    } else if(bmi>=19&&bmi<24){
        document.getElementById('immagine').src='normopeso.jpg';
        document.getElementById('paragrafo').innerHTML="sei normopeso e il tuo BMI e': " +Math.round(bmi);
    } else if(bmi>=24&&bmi<29){
        document.getElementById('immagine').src='sovrappeso.jpg';
        document.getElementById('paragrafo').innerHTML="sei sovrappeso e il tuo BMI e': " +Math.round(bmi);
    } else if(bmi>=29){
        document.getElementById('immagine').src='obeso.jpg';
        document.getElementById('paragrafo').innerHTML="sei obeso e il tuo BMI e': " +Math.round(bmi);
    }
}